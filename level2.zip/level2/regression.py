import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1. Load data
df = pd.read_csv("stock_prices.csv")

# 2. Auto-detect Columns & Clean Data
df.columns = [col.strip() for col in df.columns]
x_col = [col for col in df.columns if 'open' in col.lower()][0]
y_col = [col for col in df.columns if 'close' in col.lower() or 'price' in col.lower()][0]

# Remove any rows with missing (NaN) values
df = df.dropna(subset=[x_col, y_col])

x = df[x_col]
y = df[y_col]

# 3. Regression using Numpy
# We use a try/except block just in case the math still struggles
try:
    m, b = np.polyfit(x, y, 1)
    predictions = m*x + b

    # 4. Calculate Accuracy (R-squared)
    correlation_matrix = np.corrcoef(x, y)
    r_squared = correlation_matrix[0,1]**2

    # 5. Plot
    plt.figure(figsize=(10,6))
    plt.scatter(x, y, color='blue', alpha=0.5, label='Actual Data')
    plt.plot(x, predictions, color='red', label=f'Trend Line (R²={r_squared:.2f})')
    plt.title(f'Regression Analysis: {x_col} vs {y_col}')
    plt.xlabel(x_col)
    plt.ylabel(y_col)
    plt.legend()
    plt.savefig('regression_analysis.png')

    print(f"Success! Accuracy (R²): {r_squared:.2f}")
    print("Level 2 is now complete.")
except Exception as e:
    print(f"Error: {e}. Please check if your CSV has enough valid data.")