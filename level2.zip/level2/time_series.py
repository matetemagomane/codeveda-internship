import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose

# 1. Load data
df = pd.read_csv("stock_prices.csv")

# 2. Auto-detect Column Names
df.columns = [col.strip() for col in df.columns]
date_col = [col for col in df.columns if 'date' in col.lower()][0]
# This line finds the price column even if it's named differently
price_col = [col for col in df.columns if 'close' in col.lower() or 'price' in col.lower()][0]

# 3. Process Data
df[date_col] = pd.to_datetime(df[date_col])
df.set_index(date_col, inplace=True)
df = df.sort_index()

# 4. Moving Average and Decomposition
df['12-Month-MA'] = df[price_col].rolling(window=12).mean()
result = seasonal_decompose(df[price_col], model='multiplicative', period=12)

# 5. Save Visualizations
plt.figure(figsize=(12, 8))
result.plot()
plt.savefig('time_series_decomposition.png')

plt.figure(figsize=(10, 6))
plt.plot(df[price_col], label='Actual Price')
plt.plot(df['12-Month-MA'], label='12-Month Moving Average', color='red')
plt.title('Stock Price Trend Analysis')
plt.legend()
plt.savefig('moving_average.png')

print(f"Success! Analyzed column: {price_col}")