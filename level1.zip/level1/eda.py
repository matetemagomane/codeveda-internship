import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns 

# Load dataset
df = pd.read_csv("stock_prices.csv")

# Summary Statistics
print(df.describe())
print("Mode:\n", df.select_dtypes(include=['number']).mode().iloc[0])

# Correlations
corr = df.select_dtypes(include=['number']).corr()
sns.heatmap(corr, annot=True, cmap='coolwarm')
plt.savefig('correlation_heatmap.png')

# Distribution Plot
sns.histplot(df['close'], bins=50, kde=True)
plt.savefig('closing_price_histogram.png')

# Boxplot
sns.boxplot(data=df[['open', 'high', 'low', 'close']])
plt.savefig('stock_prices_boxplot.png')

# Scatter plot
sns.scatterplot(x='volume', y='close', data=df.sample(5000))
plt.savefig('volume_vs_close_scatter.png')
