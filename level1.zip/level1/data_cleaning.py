import pandas as pd
import numpy as np

# Load the dataset
df = pd.read_csv("data/iris.csv")

print("Initial dataset shape:", df.shape)
print(df.head())

# Introduce missing values
df.loc[5, 'sepal_length'] = np.nan
df.loc[10, 'petal_width'] = np.nan

# Introduce a duplicate row
df = pd.concat([df, df.iloc[[0]]], ignore_index=True)

# Check missing values and duplicates
print("\nMissing values:\n", df.isnull().sum())
print("Duplicate rows:", df.duplicated().sum())

# Handle missing values using mean imputation
df['sepal_length'].fillna(df['sepal_length'].mean(), inplace=True)
df['petal_width'].fillna(df['petal_width'].mean(), inplace=True)

# Remove duplicates
df.drop_duplicates(inplace=True)

# Standardize column names and categorical values
df.columns = df.columns.str.lower().str.replace(" ", "_")
df['species'] = df['species'].str.lower()

# Save cleaned dataset
df.to_csv("data/iris_cleaned.csv", index=False)

print("\nData cleaning completed. Cleaned file saved as iris_cleaned.csv")
