import pandas as pd
import matplotlib.pyplot as plt

# 1. Sample Data
data = {
    'Review': [
        "I love this stock, it's performing so well!",
        "Terrible experience, I lost so much money today.",
        "The market is quite stable and moving as expected.",
        "Highly recommended platform, very easy to use.",
        "The customer service was slow and very unhelpful.",
        "Great results this quarter, very happy with my investment.",
        "I am not sure about the future of this company.",
        "Worst app ever, it keeps crashing!"
    ]
}

df = pd.DataFrame(data)

# 2. Simple Rule-Based Sentiment (No libraries required)
pos_words = ['love', 'well', 'stable', 'recommended', 'easy', 'great', 'happy']
neg_words = ['terrible', 'lost', 'slow', 'unhelpful', 'not sure', 'worst', 'crashing']

def get_simple_sentiment(text):
    text = text.lower()
    if any(word in text for word in pos_words):
        return 'Positive'
    elif any(word in text for word in neg_words):
        return 'Negative'
    else:
        return 'Neutral'

# 3. Apply
df['Sentiment'] = df['Review'].apply(get_simple_sentiment)

# 4. Results & Visualization
sentiment_counts = df['Sentiment'].value_counts()
plt.figure(figsize=(8, 6))
sentiment_counts.plot(kind='bar', color=['green', 'red', 'gray'])
plt.title('Sentiment Distribution (Rule-Based)')
plt.savefig('sentiment_results.png')

print(df)
print("\nSuccess! Sentiment Analysis complete.")