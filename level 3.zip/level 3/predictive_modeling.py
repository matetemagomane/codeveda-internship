import pandas as pd
import matplotlib.pyplot as plt

# 1. Load data
train_df = pd.read_csv("churn-bigml-80.csv")
test_df = pd.read_csv("churn-bigml-20.csv")

# 2. Manual Prediction Rule (Heuristic Modeling)
# Logic: If Customer Service Calls > 3 or International Plan is Yes, they likely Churn
def predict_churn(row):
    if row['Customer service calls'] > 3:
        return 1
    if row['International plan'] == 'Yes':
        return 1
    return 0

# 3. Apply Prediction
test_df['Prediction'] = test_df.apply(predict_churn, axis=1)
test_df['Actual'] = test_df['Churn'].apply(lambda x: 1 if x == True else 0)

# 4. Calculate Accuracy
correct = (test_df['Prediction'] == test_df['Actual']).sum()
accuracy = correct / len(test_df)

print(f"Manual Model Accuracy: {accuracy:.2f}")

# 5. Simple Visualization
results = test_df['Prediction'].value_counts()
results.plot(kind='pie', autopct='%1.1f%%', labels=['Stay', 'Churn'], colors=['lightblue', 'orange'])
plt.title('Predicted Customer Churn Rate')
plt.savefig('churn_prediction_results.png')

print("Success! Results saved as 'churn_prediction_results.png'")